/// Một tin nhắn trong hội thoại (lưu trong SQLite).
class Message {
  int? id;
  final String conversationId;

  /// 'user' hoặc 'assistant'
  final String role;
  String content;

  /// message_index do máy chủ trả về (chỉ có với câu trả lời của EON)
  int? serverIndex;

  /// true nếu câu trả lời này được tạo khi người dùng đã bật "Cho phép lưu"
  /// (tức máy chủ đã lưu -> mới gửi được /feedback)
  bool saved;

  /// 'up' | 'down' | null
  String? rating;

  /// true nếu câu trả lời bị ngắt giữa chừng / người dùng bấm Dừng
  bool interrupted;
  final int createdAt;

  Message({
    this.id,
    required this.conversationId,
    required this.role,
    required this.content,
    this.serverIndex,
    this.saved = false,
    this.rating,
    this.interrupted = false,
    int? createdAt,
  }) : createdAt = createdAt ?? DateTime.now().millisecondsSinceEpoch;

  bool get isUser => role == 'user';

  factory Message.fromMap(Map<String, Object?> m) => Message(
        id: m['id'] as int?,
        conversationId: m['conversation_id'] as String,
        role: m['role'] as String,
        content: m['content'] as String,
        serverIndex: m['server_index'] as int?,
        saved: (m['saved'] as int? ?? 0) == 1,
        rating: m['rating'] as String?,
        interrupted: (m['interrupted'] as int? ?? 0) == 1,
        createdAt: m['created_at'] as int?,
      );

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'conversation_id': conversationId,
        'role': role,
        'content': content,
        'server_index': serverIndex,
        'saved': saved ? 1 : 0,
        'rating': rating,
        'interrupted': interrupted ? 1 : 0,
        'created_at': createdAt,
      };
}
