/// Sự kiện đọc được từ luồng SSE của /chat.
class ChatEvent {
  final String? delta; // đoạn chữ mới
  final bool done; // đã kết thúc
  final String? reply; // toàn văn (khi done)
  final int? messageIndex; // vị trí câu trả lời (khi done)

  const ChatEvent.delta(String text)
      : delta = text,
        done = false,
        reply = null,
        messageIndex = null;

  const ChatEvent.done({this.reply, this.messageIndex})
      : delta = null,
        done = true;
}

/// Kết quả của GET /health
class HealthInfo {
  final bool modelReady;
  final String? adapter;
  final int waiting;
  const HealthInfo({required this.modelReady, this.adapter, this.waiting = 0});
}

/// Nội dung server.json
class ServerInfo {
  final String? url;
  final String? adapter;
  const ServerInfo({this.url, this.adapter});
}
