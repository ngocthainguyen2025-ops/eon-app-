/// Một hội thoại. [id] chính là conversation_id (uuid) gửi lên máy chủ.
class Conversation {
  final String id;
  String title;
  final int createdAt;
  int updatedAt;

  /// true nếu đã có tin được gửi với save=true (máy chủ đang giữ bản lưu)
  bool saved;

  Conversation({
    required this.id,
    required this.title,
    required this.createdAt,
    required this.updatedAt,
    this.saved = false,
  });

  factory Conversation.fromMap(Map<String, Object?> m) => Conversation(
        id: m['id'] as String,
        title: m['title'] as String,
        createdAt: m['created_at'] as int,
        updatedAt: m['updated_at'] as int,
        saved: (m['saved'] as int? ?? 0) == 1,
      );

  Map<String, Object?> toMap() => {
        'id': id,
        'title': title,
        'created_at': createdAt,
        'updated_at': updatedAt,
        'saved': saved ? 1 : 0,
      };
}
