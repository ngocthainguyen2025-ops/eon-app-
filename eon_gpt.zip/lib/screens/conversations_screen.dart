import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/conversation.dart';
import '../services/app_state.dart';
import '../widgets/status_bar.dart';
import 'chat_screen.dart';
import 'settings_screen.dart';

/// Danh sách hội thoại: tạo mới, đổi tên, xóa, tìm.
class ConversationsScreen extends StatefulWidget {
  const ConversationsScreen({super.key});

  @override
  State<ConversationsScreen> createState() => _ConversationsScreenState();
}

class _ConversationsScreenState extends State<ConversationsScreen> {
  List<Conversation> _list = [];
  bool _searching = false;
  String _query = '';
  final _searchCtl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _reload();
  }

  @override
  void dispose() {
    _searchCtl.dispose();
    super.dispose();
  }

  Future<void> _reload() async {
    final app = context.read<AppState>();
    final l = await app.db.listConversations(query: _query);
    if (mounted) setState(() => _list = l);
  }

  Future<void> _open(String? id) async {
    await Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => ChatScreen(conversationId: id)));
    _reload();
  }

  Future<void> _rename(Conversation c) async {
    final ctl = TextEditingController(text: c.title);
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Đổi tên hội thoại'),
        content: TextField(controller: ctl, autofocus: true, maxLength: 80),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Hủy')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, ctl.text.trim()), child: const Text('Lưu')),
        ],
      ),
    );
    if (name == null || name.isEmpty || !mounted) return;
    await context.read<AppState>().db.renameConversation(c.id, name);
    _reload();
  }

  Future<void> _delete(Conversation c) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Xóa hội thoại?'),
        content: Text('"${c.title}" sẽ bị xóa khỏi điện thoại'
            '${c.saved ? ' và khỏi máy chủ (nếu máy chủ đang bật)' : ''}.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Xóa')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    final app = context.read<AppState>();
    final messenger = ScaffoldMessenger.of(context);
    var serverFailed = false;
    if (c.saved) {
      try {
        await app.forgetOnServer(c.id);
      } catch (_) {
        serverFailed = true;
      }
    }
    await app.db.deleteConversation(c.id);
    _reload();
    if (serverFailed) {
      messenger.showSnackBar(const SnackBar(
          content: Text('Đã xóa trên điện thoại, nhưng chưa xóa được bản trên máy chủ (máy chủ đang tắt?). '
              'Bạn có thể dùng "Xóa dữ liệu của tôi" sau để xóa lại.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: _searching
            ? TextField(
                controller: _searchCtl,
                autofocus: true,
                decoration: const InputDecoration(hintText: 'Tìm hội thoại…', border: InputBorder.none),
                onChanged: (v) {
                  _query = v;
                  _reload();
                },
              )
            : const Text('EON GPT'),
        actions: [
          IconButton(
            tooltip: _searching ? 'Đóng tìm kiếm' : 'Tìm',
            icon: Icon(_searching ? Icons.close : Icons.search),
            onPressed: () {
              setState(() {
                _searching = !_searching;
                if (!_searching) {
                  _query = '';
                  _searchCtl.clear();
                }
              });
              _reload();
            },
          ),
          IconButton(
            tooltip: 'Cài đặt',
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => const SettingsScreen()))
                .then((_) => _reload()),
          ),
        ],
      ),
      body: Column(
        children: [
          const ServerStatusBar(),
          Expanded(
            child: _list.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Text(
                        _query.isEmpty
                            ? 'Chưa có hội thoại nào.\nBấm nút + để bắt đầu.'
                            : 'Không tìm thấy hội thoại phù hợp.',
                        textAlign: TextAlign.center,
                      ),
                    ),
                  )
                : ListView.separated(
                    itemCount: _list.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (ctx, i) {
                      final c = _list[i];
                      return ListTile(
                        title: Text(c.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                        subtitle: Text(_fmt(c.updatedAt)),
                        onTap: () => _open(c.id),
                        trailing: PopupMenuButton<String>(
                          onSelected: (v) => v == 'rename' ? _rename(c) : _delete(c),
                          itemBuilder: (_) => const [
                            PopupMenuItem(value: 'rename', child: Text('Đổi tên')),
                            PopupMenuItem(value: 'delete', child: Text('Xóa')),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _open(null),
        icon: const Icon(Icons.add),
        label: const Text('Mới'),
      ),
    );
  }

  String _fmt(int ms) {
    final d = DateTime.fromMillisecondsSinceEpoch(ms);
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(d.day)}/${two(d.month)}/${d.year} ${two(d.hour)}:${two(d.minute)}';
  }
}
