import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_markdown/flutter_markdown.dart';

import '../models/message.dart';
import 'code_block.dart';

/// Hiển thị markdown (có khối code tô màu). Cho phép chọn/sao chép chữ.
class EonMarkdown extends StatelessWidget {
  final String data;
  const EonMarkdown(this.data, {super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    return MarkdownBody(
      data: data,
      selectable: false, // việc chọn chữ do SelectionArea bên ngoài lo
      builders: {'pre': CodeBlockBuilder()},
      onTapLink: (text, href, title) async {
        if (href == null) return;
        await Clipboard.setData(ClipboardData(text: href));
        if (context.mounted) {
          ScaffoldMessenger.of(context)
            ..hideCurrentSnackBar()
            ..showSnackBar(const SnackBar(
                content: Text('Đã sao chép liên kết'), duration: Duration(seconds: 1)));
        }
      },
      styleSheet: MarkdownStyleSheet.fromTheme(theme).copyWith(
        p: theme.textTheme.bodyMedium?.copyWith(height: 1.4),
        code: TextStyle(
          fontFamily: 'monospace',
          fontSize: 13,
          backgroundColor: cs.surfaceContainerHighest,
        ),
        codeblockPadding: EdgeInsets.zero,
        codeblockDecoration: const BoxDecoration(),
      ),
    );
  }
}

/// Bong bóng tin nhắn (người dùng hoặc EON) + hàng nút dưới câu trả lời.
class MessageBubble extends StatelessWidget {
  final Message message;
  final bool isLast; // là tin cuối cùng của hội thoại?
  final bool busy;
  final VoidCallback onRegenerate;
  final void Function(String rating) onRate;
  final VoidCallback onCorrect;

  const MessageBubble({
    super.key,
    required this.message,
    required this.isLast,
    required this.busy,
    required this.onRegenerate,
    required this.onRate,
    required this.onCorrect,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final isUser = message.isUser;
    final maxW = MediaQuery.of(context).size.width * (isUser ? 0.85 : 0.95);

    final bubble = Container(
      constraints: BoxConstraints(maxWidth: maxW),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: isUser ? cs.primaryContainer : cs.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(16),
      ),
      child: SelectionArea(
        child: isUser
            ? Text(message.content, style: TextStyle(color: cs.onPrimaryContainer, height: 1.4))
            : EonMarkdown(message.content),
      ),
    );

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Column(
        crossAxisAlignment: isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          bubble,
          if (!isUser) ...[
            if (message.interrupted)
              Padding(
                padding: const EdgeInsets.only(left: 6, top: 2),
                child: Text('Câu trả lời chưa hoàn tất',
                    style: TextStyle(fontSize: 11, color: cs.error)),
              ),
            Wrap(
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                IconButton(
                  tooltip: 'Hay',
                  visualDensity: VisualDensity.compact,
                  icon: const Text('👍', style: TextStyle(fontSize: 18)),
                  isSelected: message.rating == 'up',
                  style: message.rating == 'up'
                      ? IconButton.styleFrom(backgroundColor: cs.primaryContainer)
                      : null,
                  onPressed: () => onRate('up'),
                ),
                IconButton(
                  tooltip: 'Chưa tốt',
                  visualDensity: VisualDensity.compact,
                  icon: const Text('👎', style: TextStyle(fontSize: 18)),
                  isSelected: message.rating == 'down',
                  style: message.rating == 'down'
                      ? IconButton.styleFrom(backgroundColor: cs.errorContainer)
                      : null,
                  onPressed: () => onRate('down'),
                ),
                TextButton.icon(
                  style: TextButton.styleFrom(visualDensity: VisualDensity.compact),
                  icon: const Icon(Icons.edit_outlined, size: 16),
                  label: const Text('Sửa câu trả lời'),
                  onPressed: onCorrect,
                ),
                if (isLast && !busy)
                  TextButton.icon(
                    style: TextButton.styleFrom(visualDensity: VisualDensity.compact),
                    icon: const Icon(Icons.refresh, size: 16),
                    label: const Text('Tạo lại'),
                    onPressed: onRegenerate,
                  ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

/// Bong bóng đang chạy chữ (streaming).
class StreamingBubble extends StatelessWidget {
  final String text;
  final String? notice;
  const StreamingBubble({super.key, required this.text, this.notice});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.95),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: cs.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(16),
        ),
        child: text.isEmpty
            ? Row(mainAxisSize: MainAxisSize.min, children: [
                const SizedBox(
                    width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2)),
                const SizedBox(width: 10),
                Text(notice ?? 'EON đang suy nghĩ…',
                    style: TextStyle(color: cs.onSurfaceVariant)),
              ])
            : EonMarkdown(text),
      ),
    );
  }
}
