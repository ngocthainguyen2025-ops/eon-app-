import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/chat_event.dart';

/// Đọc địa chỉ máy chủ hiện tại từ server.json trên Hugging Face
/// (địa chỉ cloudflared đổi mỗi phiên Kaggle).
class DiscoveryService {
  static const serverJsonUrl =
      'https://huggingface.co/datasets/Thai2011/eon-server/resolve/main/server.json';

  /// Trả null nếu không đọc được hoặc url = null (máy chủ đang tắt).
  /// Chỉ chấp nhận địa chỉ https.
  Future<ServerInfo?> fetch() async {
    try {
      final cb = DateTime.now().millisecondsSinceEpoch; // chống cache
      final r = await http
          .get(Uri.parse('$serverJsonUrl?cb=$cb'), headers: {'Cache-Control': 'no-cache'})
          .timeout(const Duration(seconds: 10));
      if (r.statusCode != 200) return null;
      final j = jsonDecode(utf8.decode(r.bodyBytes));
      if (j is! Map) return null;
      final raw = j['url'];
      if (raw is! String || !raw.startsWith('https://')) return null;
      String url = raw.trim();
      while (url.endsWith('/')) {
        url = url.substring(0, url.length - 1);
      }
      return ServerInfo(url: url, adapter: j['adapter']?.toString());
    } catch (_) {
      return null;
    }
  }
}
