import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/app_settings.dart';

/// Lưu cài đặt. Khóa API nằm trong flutter_secure_storage (Android Keystore),
/// còn lại nằm trong SharedPreferences. Khóa KHÔNG có trong mã nguồn.
class SettingsStore {
  static const _secure = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );
  static const _kKey = 'api_key';

  Future<AppSettings> load() async {
    final p = await SharedPreferences.getInstance();
    String key = '';
    try {
      key = await _secure.read(key: _kKey) ?? '';
    } catch (_) {
      // Keystore hỏng (hiếm): xóa để người dùng nhập lại
      try {
        await _secure.deleteAll();
      } catch (_) {}
    }
    final themeIdx = p.getInt('theme') ?? 0;
    return AppSettings(
      manualUrl: p.getString('manual_url') ?? '',
      apiKey: key,
      temperature: p.getDouble('temperature') ?? 0.7,
      maxTokens: p.getInt('max_tokens') ?? 512,
      saveAllowed: p.getBool('save_allowed') ?? false, // mặc định TẮT
      themeMode: ThemeMode.values[themeIdx.clamp(0, ThemeMode.values.length - 1)],
      privacySeen: p.getBool('privacy_seen') ?? false,
    );
  }

  Future<void> saveApiKey(String key) async {
    if (key.isEmpty) {
      await _secure.delete(key: _kKey);
    } else {
      await _secure.write(key: _kKey, value: key);
    }
  }

  Future<void> saveManualUrl(String v) async =>
      (await SharedPreferences.getInstance()).setString('manual_url', v);
  Future<void> saveTemperature(double v) async =>
      (await SharedPreferences.getInstance()).setDouble('temperature', v);
  Future<void> saveMaxTokens(int v) async =>
      (await SharedPreferences.getInstance()).setInt('max_tokens', v);
  Future<void> saveSaveAllowed(bool v) async =>
      (await SharedPreferences.getInstance()).setBool('save_allowed', v);
  Future<void> saveThemeMode(ThemeMode v) async =>
      (await SharedPreferences.getInstance()).setInt('theme', v.index);
  Future<void> savePrivacySeen(bool v) async =>
      (await SharedPreferences.getInstance()).setBool('privacy_seen', v);
}
