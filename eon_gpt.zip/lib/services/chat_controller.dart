import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import '../models/conversation.dart';
import '../models/message.dart';
import 'api_service.dart';
import 'app_state.dart';

/// Điều khiển một cuộc trò chuyện: gửi tin, nhận luồng, lưu SQLite, phản hồi.
class ChatController extends ChangeNotifier {
  ChatController(this.app, this._convId);

  final AppState app;
  String? _convId; // null = hội thoại mới, chưa tạo

  String title = 'Cuộc trò chuyện mới';
  List<Message> messages = [];

  bool busy = false; // đang chờ/nhận câu trả lời
  String streaming = ''; // phần chữ đang chạy
  String? notice; // thông báo tạm (vd. "Máy bận, thử lại lần 1…")
  String? error; // lỗi hiện dưới cùng, kèm nút "Thử lại"

  CancelToken? _token;
  Timer? _throttle;
  bool _disposed = false;

  static const _maxTurns = 12; // gửi tối đa 12 lượt (= 24 tin) gần nhất
  static const _maxChars = 6000;

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  void _scheduleNotify() {
    if (_throttle?.isActive ?? false) return;
    _throttle = Timer(const Duration(milliseconds: 80), _notify);
  }

  @override
  void dispose() {
    _disposed = true;
    _throttle?.cancel();
    _token?.cancel();
    super.dispose();
  }

  Future<void> load() async {
    final id = _convId;
    if (id != null) {
      final c = await app.db.getConversation(id);
      if (c != null) title = c.title;
      messages = await app.db.listMessages(id);
    }
    _notify();
  }

  // ---------- Gửi / Tạo lại / Dừng ----------
  Future<void> send(String text) async {
    text = text.trim();
    if (text.isEmpty || busy) return;
    if (text.length > _maxChars) text = text.substring(0, _maxChars);
    final id = await _ensureConversation(text);
    final m = Message(conversationId: id, role: 'user', content: text);
    m.id = await app.db.insertMessage(m);
    messages.add(m);
    await app.db.touchConversation(id);
    _notify();
    await _generate();
  }

  /// "Tạo lại" / "Thử lại": bỏ câu trả lời cuối của EON (nếu có) rồi hỏi lại.
  Future<void> regenerate() async {
    if (busy) return;
    if (messages.isNotEmpty && messages.last.role == 'assistant') {
      final last = messages.removeLast();
      if (last.id != null) await app.db.deleteMessage(last.id!);
    }
    if (messages.isEmpty || messages.last.role != 'user') {
      _notify();
      return;
    }
    await _generate();
  }

  void stop() => _token?.cancel();

  Future<String> _ensureConversation(String firstText) async {
    final existing = _convId;
    if (existing != null) return existing;
    final id = const Uuid().v4();
    final oneLine = firstText.replaceAll(RegExp(r'\s+'), ' ').trim();
    title = oneLine.length > 40 ? '${oneLine.substring(0, 40)}…' : oneLine;
    final now = DateTime.now().millisecondsSinceEpoch;
    await app.db.insertConversation(
        Conversation(id: id, title: title, createdAt: now, updatedAt: now));
    _convId = id;
    return id;
  }

  /// Dựng danh sách gửi lên máy chủ: xen kẽ user/assistant, bắt đầu và kết thúc
  /// bằng user, tối đa 12 lượt gần nhất, mỗi tin <= 6000 ký tự.
  List<Map<String, String>> _buildPayload() {
    final out = <Map<String, String>>[];
    for (final m in messages) {
      var c = m.content.trim();
      if (c.isEmpty) continue;
      if (out.isNotEmpty && out.last['role'] == m.role) {
        c = '${out.last['content']}\n\n$c'; // gộp 2 tin liên tiếp cùng vai
        out.last['content'] = c.length > _maxChars ? c.substring(0, _maxChars) : c;
      } else {
        out.add({'role': m.role, 'content': c.length > _maxChars ? c.substring(0, _maxChars) : c});
      }
    }
    final keep = _maxTurns * 2;
    var list = out.length > keep ? out.sublist(out.length - keep) : out;
    list = List<Map<String, String>>.of(list);
    while (list.isNotEmpty && list.first['role'] != 'user') {
      list.removeAt(0);
    }
    while (list.isNotEmpty && list.last['role'] != 'user') {
      list.removeLast();
    }
    return list;
  }

  Future<void> _generate({bool retried = false}) async {
    final convId = _convId!;
    busy = true;
    error = null;
    notice = null;
    streaming = '';
    _notify();

    final token = CancelToken();
    _token = token;
    var got = false;
    var retry = false;
    final saveFlag = app.settings.saveAllowed; // chỉ gửi save=true khi đã bật
    String? usedUrl;

    try {
      final s = await app.requireServer();
      usedUrl = s.url;
      final payload = _buildPayload();
      if (payload.isEmpty) {
        error = 'Không có nội dung để gửi.';
        return;
      }

      String? finalReply;
      int? index;
      final events = app.api.chatStream(
        baseUrl: s.url,
        apiKey: s.key,
        messages: payload,
        temperature: app.settings.temperature,
        maxTokens: app.settings.maxTokens,
        save: saveFlag,
        conversationId: convId,
        token: token,
        onRetry: (n) {
          notice = 'Máy chủ đang bận, thử lại lần $n/3…';
          _notify();
        },
      );
      await for (final ev in events) {
        if (ev.delta != null) {
          got = true;
          notice = null;
          streaming += ev.delta!;
          _scheduleNotify();
        } else if (ev.done) {
          finalReply = ev.reply;
          index = ev.messageIndex;
        }
      }

      if (finalReply != null) {
        final text = finalReply.isNotEmpty ? finalReply : streaming;
        if (text.trim().isEmpty) {
          error = 'Máy chủ trả về câu trả lời rỗng. Hãy thử lại.';
        } else {
          await _addAssistant(convId, text, saved: saveFlag, index: index);
        }
      } else {
        // Người dùng bấm Dừng (hoặc luồng kết thúc không có "done"): giữ phần đã nhận
        await _commitPartial(convId);
      }
    } on ApiException catch (e) {
      if (token.cancelled) {
        await _commitPartial(convId);
      } else if (e.isNetwork && got) {
        await _commitPartial(convId);
        error = 'Kết nối bị ngắt giữa chừng. Phần đã nhận được giữ lại — bấm "Tạo lại" để hỏi lại.';
        app.refreshServer(); // đọc lại server.json
      } else if (e.isNetwork) {
        // Lỗi mạng khi chưa nhận được gì: đọc lại server.json, nếu địa chỉ mới thì tự thử lại 1 lần
        await app.refreshServer();
        if (!retried && app.baseUrl != null && app.baseUrl != usedUrl && app.status != ServerStatus.off) {
          retry = true;
        } else {
          error = e.message;
        }
      } else {
        error = e.message;
      }
    } catch (_) {
      await _commitPartial(convId);
      error = 'Có lỗi không mong muốn. Hãy thử lại.';
    } finally {
      if (!retry) {
        busy = false;
        notice = null;
        streaming = '';
        _token = null;
        _notify();
      }
    }
    if (retry) await _generate(retried: true);
  }

  Future<void> _addAssistant(String convId, String text,
      {required bool saved, int? index, bool interrupted = false}) async {
    final m = Message(
      conversationId: convId,
      role: 'assistant',
      content: text,
      saved: saved && index != null,
      serverIndex: index,
      interrupted: interrupted,
    );
    m.id = await app.db.insertMessage(m);
    messages.add(m);
    await app.db.touchConversation(convId);
    if (m.saved) await app.db.markConversationSaved(convId);
  }

  Future<void> _commitPartial(String convId) async {
    if (streaming.trim().isEmpty) return;
    await _addAssistant(convId, streaming, saved: false, interrupted: true);
    streaming = '';
  }

  // ---------- Phản hồi 👍 👎 / sửa câu ----------
  static const _notSavedMsg =
      'Câu trả lời này chưa được lưu trên máy chủ nên không gửi phản hồi được. '
      'Hãy bật "Cho phép lưu hội thoại" trong Cài đặt rồi trò chuyện tiếp.';

  /// Trả về chuỗi lỗi, hoặc null nếu gửi thành công.
  Future<String?> rate(Message m, String rating) async {
    if (!m.saved || m.serverIndex == null || _convId == null) return _notSavedMsg;
    try {
      final s = await app.requireServer();
      await app.api.feedback(
          baseUrl: s.url,
          apiKey: s.key,
          conversationId: _convId!,
          messageIndex: m.serverIndex!,
          rating: rating);
    } on ApiException catch (e) {
      return e.message;
    }
    m.rating = rating;
    if (m.id != null) await app.db.updateRating(m.id!, rating);
    _notify();
    return null;
  }

  Future<String?> correct(Message m, String corrected) async {
    if (!m.saved || m.serverIndex == null || _convId == null) return _notSavedMsg;
    var text = corrected.trim();
    if (text.isEmpty) return 'Bạn chưa nhập câu trả lời đúng.';
    if (text.length > 4000) text = text.substring(0, 4000);
    try {
      final s = await app.requireServer();
      await app.api.feedback(
          baseUrl: s.url,
          apiKey: s.key,
          conversationId: _convId!,
          messageIndex: m.serverIndex!,
          correctedText: text);
    } on ApiException catch (e) {
      return e.message;
    }
    return null;
  }
}
